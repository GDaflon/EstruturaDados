package app; 

import view.AutomovelView;

public class Main {
    public static void main(String[] args) {
        new AutomovelView().exibirMenu();
    }
}
